
AAAAAAAAAAA
===========

.. Contents:

.. toctree::
   :maxdepth: 2
   
   file1
   file2
   file3

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

