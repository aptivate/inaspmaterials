Misc Markup
===========

.. sectionauthor:: Roberto Alsina <ralsina@netmanagers.com.ar>

.. only:: html

   This shows in HTML, not in PDF
   
.. only:: pdf

   This shows in PDF, not in HTML

