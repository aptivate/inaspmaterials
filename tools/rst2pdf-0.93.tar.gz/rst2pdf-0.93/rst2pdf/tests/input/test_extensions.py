import sys

print """

This test should print the message from the sample extension,
and then this message, and then generate an empty PDF.
"""
