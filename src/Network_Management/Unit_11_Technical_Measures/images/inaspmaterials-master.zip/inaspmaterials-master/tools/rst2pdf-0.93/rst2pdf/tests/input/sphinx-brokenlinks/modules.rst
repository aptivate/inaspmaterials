
MODULES
=======
.. index::
   module: grail

.. _the-parrot-module:

The parrot module
-----------------

.. module:: parrot
   :platform: Unix, Windows
   :synopsis: Analyze and reanimate dead parrots.

This is about parrot
