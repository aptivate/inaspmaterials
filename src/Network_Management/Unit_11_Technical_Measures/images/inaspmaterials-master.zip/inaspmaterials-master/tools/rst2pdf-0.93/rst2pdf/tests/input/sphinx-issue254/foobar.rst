jabberwocky.txt:

.. literalinclude:: jabberwocky.txt
   :encoding: latin-1


jabberwocky with 4-space tabs:

.. include:: jabberwocky.txt
   :encoding: latin-1
   :tab-width: 4
   :literal:
