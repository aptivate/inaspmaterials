.. Test Case documentation master file, created by
   sphinx-quickstart on Mon Nov 02 15:48:51 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


.. toctree::
   :maxdepth: 2

   Doc1
   Doc2
   

