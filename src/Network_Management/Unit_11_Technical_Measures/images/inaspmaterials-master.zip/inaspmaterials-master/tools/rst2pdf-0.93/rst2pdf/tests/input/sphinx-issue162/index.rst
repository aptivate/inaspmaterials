.. code-block:: rst

   A title
   =======
   
   Whatever *bold*

::

   A title
   =======
   
   Whatever *bold*

.. code-block:: html

   <a href='whatever'>X</a>
   
::

   <a href='whatever'>X</a>