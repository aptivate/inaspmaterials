.. include:: _substitutions.txt
Kontext sensitive Hilfe
=======================

Kontext sensitive Hilfe ist seit der ersten Version von |prodname| verfügbar in allen unterstützten Sprachen.



Überall im System wo Sie die obige Taste sehen (entweder auf der Symbolleiste oder auf den Dialogen neben den anderen Tasten) können Sie sie anklicken und dann das Feld/Kontrolle/Widget anklicken für das Sie Hilfe anfragen wollen.

Diese Hilfe gibt eine kurze Beschreibung der Funktionalität von allen Feldern und Tasten im System.
