def f():
    a = 1
    b = 2

