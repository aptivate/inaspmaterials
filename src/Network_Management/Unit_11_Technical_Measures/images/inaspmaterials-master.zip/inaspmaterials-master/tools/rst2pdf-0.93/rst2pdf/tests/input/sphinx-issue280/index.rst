Sphynx example document
-----------------------

Nothing interesting here

