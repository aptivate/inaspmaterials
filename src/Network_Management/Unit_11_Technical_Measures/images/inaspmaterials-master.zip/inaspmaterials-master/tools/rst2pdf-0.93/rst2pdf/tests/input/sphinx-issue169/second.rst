.. program:: svn

.. cmdoption:: -r revision

   Specify the revision to work upon.
   
:option:`svn -r` should link to the definition for svn.
:option:`rm -r` should link to the definition for rm.

