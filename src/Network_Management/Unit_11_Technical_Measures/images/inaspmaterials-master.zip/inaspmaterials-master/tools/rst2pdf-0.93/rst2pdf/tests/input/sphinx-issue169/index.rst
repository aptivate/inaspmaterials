.. program:: rm

.. cmdoption:: -r

   Delete recursively
   
:option:`svn -r` should link to the definition for svn.
:option:`rm -r` should link to the definition for rm.


.. toctree:: 

   second
   
