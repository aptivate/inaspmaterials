INASP: Effective Network Management Workshops
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

..	The following references are included here to be usable in any
	source file as
	`Indirect hyperlink targets <http://docutils.sourceforge.net/docs/user/rst/quickref.html#indirect-hyperlink-targets>`_.
	For example, you can write Cacti_ or Nagios_ anywhere to refer to them.

.. _Cacti: http://www.cacti.net/
.. _Nagios: 