About these workshops
---------------------

Authors:

* Dick Elleray, AfriConnect

    * delleray@africonnect.com

* Chris Wilson, Aptivate

    * chris+inaspbmo2013@aptivate.org

Date: 2013-04-29
