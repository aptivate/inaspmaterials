What is network management?
---------------------------

ISO network management model:

* Faults
* Configurations
* Performance
* Security
* Accounting

See Cisco's `Network Management System: Best Practices White Paper
<http://www.cisco.com/en/US/solutions/collateral/ns341/ns525/ns537/ns705/ns827/
white_paper_c11-481360_ns827_Networking_Solutions_White_Paper.html>`_.

