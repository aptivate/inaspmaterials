Summary
-------

Hopefully you now feel confident with:

* Good practice in network management
* Identifying and solving problems
* Detecting and predicting problems
* Preparing for disasters
* The role of policy in guiding/changing behaviour

.. class:: handout

Please take a moment to reflect, review and share your learnings and
plans for action with the group.
